"""ShopBuddy Streamlit pages."""
