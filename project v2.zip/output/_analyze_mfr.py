﻿import json
from pathlib import Path

p = Path(r"d:\ai-shopping-agent-v2\output\laptop_live_report.json")
d = json.load(p.open(encoding="utf-8"))
out = Path(r"d:\ai-shopping-agent-v2\output\_mfr_analysis.txt")
lines = []
for i, r in enumerate(d.get("recommendations", []), 1):
    lines.append(f"\n===== #{i} {r.get('model')} =====")
    lines.append(f"name: {r.get('name')}")
    lines.append(f"configuration: {r.get('configuration')}")
    lines.append(f"score={r.get('score')} provisional={r.get('provisional')}")
    lines.append(f"reasons: {r.get('reasons')}")
    for k, v in (r.get("specifications") or {}).items():
        if not isinstance(v, dict):
            continue
        lines.append(f"SPEC {k}: status={v.get('status')} strength={v.get('evidence_strength')} value={v.get('value')!r} source_type={v.get('source_type')}")
        lines.append(f"  url: {v.get('source_url')}")
        lines.append(f"  reason: {(v.get('reason') or '')[:600]}")
        lines.append(f"  support: {(v.get('supporting_text') or '')[:300]}")
    for e in r.get("evidence") or []:
        if (e.get("field_name") or "").startswith("manufacturer") or e.get("source_type") == "manufacturer_page":
            lines.append(f"EVID {e.get('field_name')}: status={e.get('status')} strength={e.get('evidence_strength')}")
            lines.append(f"  url: {e.get('source_url')}")
            lines.append(f"  reason: {(e.get('reason') or '')[:700]}")
            lines.append(f"  support: {(e.get('supporting_text') or '')[:300]}")

# count strong manufacturer specs
lines.append("\n===== STRONG MFR SUMMARY =====")
for r in d.get("recommendations", []):
    strong = []
    for k, v in (r.get("specifications") or {}).items():
        if isinstance(v, dict) and v.get("evidence_strength") == "strong" and (v.get("source_type") or "").startswith("manufacturer"):
            strong.append(f"{k}={v.get('value')}")
    lines.append(f"{r.get('model')}: strong_mfr={len(strong)} -> {strong}")

out.write_text("\n".join(lines), encoding="utf-8")
print(f"wrote {out} ({out.stat().st_size} bytes)")
