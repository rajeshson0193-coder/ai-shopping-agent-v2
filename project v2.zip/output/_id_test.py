﻿from shopping_agent.profiles.laptops import extract_identity, page_hints_for_model, PROFILE
from shopping_agent.spec_extract import page_mentions_model

titles = [
 "Dell Inspiron 14 7425 2-in-1 Ryzen 7 5825U  16GB 512GB SSD Windows 11 Home",
 "Dell Inspiron 15 3535 15.6 FHD Touch Ryzen 7 7730U 16GB 512GB SSD W11H Laptop",
 "Lenovo IdeaPad Slim 3 Laptop 15.6 FHD Touch / Ryzen 7 5825U / 16GB / 512GB NEW",
 "HP Pavilion 15 Notebook - 15 15-p227NR - AMD A10-5745M - 8GB 1TB HD Win 10 H093",
 "Lenovo IdeaPad Slim 3 15AMN8 15.6 Laptop AMD Ryzen 5",
 "Lenovo IdeaPad Slim 3i 15.6 Full HD Laptop",
]
for t in titles:
    b,m,c = extract_identity(t)
    print("TITLE:", t[:100])
    print("  ID:", b, "/", m, "/", c)
    if m:
        hints = page_hints_for_model(m)
        print("  HINTS:")
        for h in hints:
            ok = PROFILE.allowed_manufacturer_url(m, h)
            print("   ", ok, h)
    print()

# page_mentions_model behavior for wrong chassis
print("MENTIONS 3530 PDF for Inspiron 15:", page_mentions_model("Inspiron 15 3530 Owner Manual", "Dell Inspiron 15"))
print("MENTIONS 5440 shop for Inspiron 14:", page_mentions_model("Shop Inspiron 14 laptop family inspiron-14-5440", "Dell Inspiron 14"))
print("MENTIONS Pavilion PDF for Pavilion 15:", page_mentions_model("HP Pavilion Laptop 15 and accessories", "HP Pavilion 15"))
print("MENTIONS 7425 text:", page_mentions_model("Inspiron 14 7425 2-in-1", "Dell Inspiron 14"))
